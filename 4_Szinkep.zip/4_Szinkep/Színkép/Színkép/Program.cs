﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Színkép
{
	class Szín
	{
		public int red;
		public int blue;
		public int green;

		public Szín(string sor)
		{
			string[] temp = sor.Split(' ');
			red = int.Parse(temp[0]);
			blue = int.Parse(temp[1]);
			green = int.Parse(temp[2]);
		}
	}
	internal class Program
	{
		static List<Szín> lista = new List<Szín>();
		static void beolvas()
		{
			StreamReader sr = new StreamReader("kep.txt");
			while (!sr.EndOfStream)
			{
				Szín uj = new Szín(sr.ReadLine());
				lista.Add(uj);

			}
			sr.Close();
		}
		static void kiir()
		{
			foreach (var item in lista)
			{
				Console.WriteLine(item.red);

			}

		}
		static void f2()
		{
			Console.WriteLine("2.feladat");
			Console.WriteLine("Adjon megy egy RGB kód vörös színét: ");
			int kódv = int.Parse(Console.ReadLine());
			Console.WriteLine("Adjon megy egy RGB kód zöld színét: ");
			int kódz = int.Parse(Console.ReadLine());
			Console.WriteLine("Adjon megy egy RGB kód kék színét: ");
			int kódk = int.Parse(Console.ReadLine());
			int darab = 0;
			foreach (var item in lista)
			{
				if (item.green == kódz && item.red==kódv && item.blue == kódk)
				{
					darab++;

				}
			}
			if (darab>0)
			{
				Console.WriteLine("A megadott RGB kód szerepel a képen");

			}
			else
			{
				Console.WriteLine("A megadott RGB kód nem szerepel a képen");
			}
		}
		static void f3()
		{
			Console.WriteLine("3.feladat");

		}
		static void f4()
		{
			Console.WriteLine("4.feladat");
			int v = 0;
			int z = 0;
			int k = 0;
			
			
			foreach (var item in lista)
			{
				if (item.red==255 && item.green==0 && item.blue ==0)
				{
					v++;

				}
				if (item.red == 0 && item.green == 255 && item.blue == 0)
				{
					z++;
				}
				if (item.red == 0 && item.green == 0 && item.blue == 255)
				{
					k++;

				}

			}
			
			if (v>z && v>k)
			{
				Console.WriteLine($"A piros szín fordult elő legtöbbször");

			}
			if (z>v && z>k)
			{
				Console.WriteLine("A zöld szín fordult elő a legtöbbször");

			}
			if (k>z && k>v)
			{
				Console.WriteLine("A kék szín fordult elő a legtöbbször");

			}
		}
		static void f5()
		{
			Console.WriteLine("5.feladat");
			StreamWriter sr = new StreamWriter("kep.txt",true);
			lista.Insert(0, new Szín("0 0 0"));
			lista.Insert(1, new Szín("0 0 0"));


			foreach (var item in lista)
			{
				sr.WriteLine($"0 0 0");
				sr.WriteLine($"0 0 0");
				break;

			}
			sr.Close();
		}
		static void Main(string[] args)
		{
			beolvas();
			//kiir();
			//f2();
			f4();
			f5();

			Console.ReadKey();
		}
	}
}
