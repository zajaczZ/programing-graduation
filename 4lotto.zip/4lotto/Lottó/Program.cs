﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Lottó
{
    internal class Program
    {
       static List<List<int>> lista = new List<List<int>>();
        static void beolvas()
        {
            StreamReader sr = new StreamReader("lottosz.dat");
            while (!sr.EndOfStream)
            {
                List<int> sor = Array.ConvertAll(sr.ReadLine().Split(' '), elem => Convert.ToInt32(elem)).ToList();
                lista.Add(sor);   
            }
            sr.Close();
        }
        static void kiir()
        {
            foreach (var item in lista)
            {
                foreach (var igo in item)
                {
                    Console.Write(igo+" ");
                }
                Console.WriteLine();
            }
        }
        static void f1()
        {
            Console.WriteLine("első szám: ");
            int elso= Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("második szám: ");
            int masodik = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("harmadik szám: ");
            int harmadik = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("negyedik szám:");
            int negyedik = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("ötödik szám:");
            int otodik = Convert.ToInt32(Console.ReadLine());
            List<int> sor = new List<int> { elso, masodik, harmadik, negyedik, otodik };
            sor.Sort();
            sor.Reverse();
            lista.Add(sor);
            foreach (var item in lista)
            {
                foreach (var igo in item)
                {
                    Console.Write(igo+" ");
                }
                Console.WriteLine();
            }
            StreamWriter sr = new StreamWriter("lotto52.ki");
            for (int i = 0; i < lista.Count; i++)
            {
                for (int j = 0; j < lista[i].Count; j++)
                {
                    sr.Write($"{lista[i][j]}"+" ");
                }
                sr.WriteLine(" ");
            }
            sr.Close();

        }
        static void f3()
        {
            Console.WriteLine("Bekért szám: ");
            int szam = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < lista.Count; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    Console.Write($"{lista[szam-1][j]} ");
                    
                }
                    break;
                
            }
        }
        static void f5()
        {
            List<int> lista = new List<int>();
            int darab = 0;
            bool vane = false;
            List<int> sor = new List<int>();

            while (darab < 51)
            {
                darab++;
                sor.Add(darab);
            }


            if (lista.SequenceEqual(sor))
            {
                vane = true;
            }


            if (vane == true)
            {
                Console.WriteLine("Nincs");
            }
            else
            {
                Console.WriteLine("van");
                
            }

        }
        static void f6()
        {
            int paratlan = 0;
            for (int i = 0; i < lista.Count; i++)
            {
                for (int j = 0; j < lista[i].Count; j++)
                {
                    if (lista[i][j]%2!=0)
                    {
                        paratlan++;
                    }
                }
            }
            Console.WriteLine($"{paratlan} alkalommal van páratlan szám");
        }
        static void f8()
        {
            Dictionary<int, int> stat = new Dictionary<int, int>();
            for (int i = 0; i < lista.Count; i++)
            {
                for (int j = 0; j < lista[i].Count; j++)
                {
                    int kulcs = lista[i][j];
                    if (!stat.ContainsKey(kulcs))
                    {
                        stat.Add(kulcs, 0);
                    }
                    stat[kulcs]++;
                    

                }

            }
            var sortedStat = stat.OrderBy(x => x.Key);


            foreach (var item in sortedStat)
            {
                Console.WriteLine($"{item.Key}-{item.Value}");
            }

            
        }
        static void Main(string[] args)
        {
            beolvas();
            //kiir();
            f1();
            f3();
            f5();
            f6();
            f8();

            Console.ReadKey();
        }
    }
}
