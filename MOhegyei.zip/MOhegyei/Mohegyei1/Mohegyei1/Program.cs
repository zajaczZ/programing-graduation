﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mohegyei1
{
	class Hegy
	{
		public string hegycsucs;
		public string hegyseg;
		public int magassag;
		public Hegy(string sor)
		{
			string[] temp = sor.Split(';');
			hegycsucs = temp[0];
			hegyseg = temp[1];
			magassag = int.Parse(temp[2]);
		}

	}
	internal class Program
	{
		static List<Hegy> lista = new List<Hegy>();
		static void beolvas()
		{
			StreamReader sr = new StreamReader("hegyekMo.txt");
			sr.ReadLine();
			while (!sr.EndOfStream)
			{
				Hegy uj = new Hegy(sr.ReadLine());
				lista.Add(uj);

			}
			sr.Close();
		}
		static void kiir()
		{
			foreach (var item in lista)
			{
				Console.WriteLine(item.magassag);

			}
		}
		static void f3()
		{
			Console.WriteLine($"3.feladat: Hegycsúcsok száma: {lista.Count} db");
		}
		static void f4()
		{

			Console.WriteLine($"4.feladat: Hegycsúcsok átlagos magassága: {lista.Average(x=>x.magassag)} m");
		}
		static void f5()
		{
			int magas = lista.Max(x => x.magassag);
			foreach (var item in lista)
			{
				if (item.magassag==magas)
				{
					Console.WriteLine($"Név: {item.hegycsucs}");
					Console.WriteLine($"Hegység: {item.hegyseg}");
					Console.WriteLine($"Magasság: {item.magassag} m");
					break;
				}

			}
		}
		static void f6()
		{
			Console.WriteLine("Kérek egy magasságot: ");
			int magas = int.Parse(Console.ReadLine());
			int darab = 0;
			foreach (var item in lista)
			{
				if (item.magassag>magas)
				{
					darab++;
					Console.WriteLine($"Van {magas} m-nél magasabb hegycsúcs a {item.hegyseg}");
					break;
				}

			}
			if (darab==0)
			{
				Console.WriteLine("Nincs magasabb hegycsúcs");

			}
		}
		static void f7()
		{
			int darab = 0;
			foreach (var item in lista)
			{
				if (item.magassag*3.280>3000)
				{
					darab++;
				}

			}
			Console.WriteLine($"7.feladat: 3000 lábnál magasabb hegycsúcsok száma: {darab}");
		}
		static void f8()
		{
			Dictionary<string, int> stat = new Dictionary<string, int>();
			foreach (var item in lista)
			{
				string kulcs = item.hegyseg;
				if (!stat.ContainsKey(kulcs))
				{
					stat.Add(kulcs, 0);
				}
				stat[kulcs]++;

			}
			foreach (var item in stat)
			{
				Console.WriteLine($"{item.Key}: {item.Value} db");

			}
		}
		static void f9()
		{
			Console.WriteLine("9.feladat: bukk-videk.txt");
			StreamWriter sr = new StreamWriter("bukk-videk.txt");
			foreach (var item in lista)
			{
				if (item.hegyseg=="Bükk-vidék")
				{
					sr.WriteLine($"{item.hegycsucs};{Math.Round((double)item.magassag*3.280839895,1)}");
				}

			}
		}

		static void Main(string[] args)
		{
			beolvas();
			//kiir();
			f3();
			f4();
			f5();
			f6();
			f7();
			f8();
			f9();


			Console.ReadKey();
		}
	}
}
