﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fogadoora
{
    class Fogado
    {
        public string vnev;
        public string knev;
        public string teljesnev;
        public TimeSpan ido;
        public DateTime mikor;

    public Fogado(string sor)
     {
        string[] temp = sor.Split(' ');
        vnev = temp[0];
          knev = temp[1];
            teljesnev= temp[0]+" "+temp[1];
         ido = TimeSpan.Parse(temp[2]);
        mikor = Convert.ToDateTime(temp[3]);
     }
    }
    internal class Program
    {
        static List<Fogado> lista = new List<Fogado>();
        static void beolvsa()
        {
            StreamReader sr = new StreamReader("fogado.txt");
            while (!sr.EndOfStream)
            {
                Fogado uj = new Fogado(sr.ReadLine());
                lista.Add(uj);
            }
            sr.Close();
        }
        static void kiir()
        {
            foreach (var item in lista)
            {
                Console.WriteLine(item.teljesnev);

            }
        }
        static void f2()
        {
            Console.WriteLine("2.feladat");
            Console.WriteLine($"Foglalások száma: {lista.Count()}");
        }
        static void f3()
        {
            Console.WriteLine("3.feladat");
            Console.WriteLine("Adjon meg egy nevet: ");
            string name= Console.ReadLine();
            int darab = 0;
            foreach (var item in lista)
            {
                if (item.teljesnev==name)
                {
                    darab++;
                }

            }
            if (darab>0)
            {
                Console.WriteLine($"{name} néven {darab} időpontfoglalás van.");
            }
            else
            {
                Console.WriteLine("A megadott néven nincs időpontfoglalás");
            }
        }
        static void f4()
        {
            Console.WriteLine("4.feladat");
            Console.WriteLine("Adjon meg egy érvényes időpontot: ");
            TimeSpan idopont= TimeSpan.Parse(Console.ReadLine());
            string idoString = idopont.ToString("hh':'mm");
            idoString = idoString.Replace(":", "");
            int idopont2 = int.Parse(idoString);
            StreamWriter sr = new StreamWriter($"{idopont2}.txt");
            List<string> nevek = new List<string>();
            foreach (var item in lista)
            {

                if (idopont.Hours==item.ido.Hours && idopont.Minutes==item.ido.Minutes)
                {
                    nevek.Add(item.teljesnev);

                }
            }
            nevek.Sort();
            foreach (var item in nevek)
            {
                sr.WriteLine(item);

            }


                sr.Close();
        }
        static void f5()
        {
            Console.WriteLine("5.feladat");
            DateTime koran = lista.Min(x => x.mikor);
            foreach (var item in lista)
            {
                if (koran==item.mikor)
                {
                    Console.WriteLine($"Foglalt tanár neve: {item.teljesnev}");
                    Console.WriteLine($"Foglalt időpont:  {item.ido}");
                    Console.WriteLine($"Foglalás ideje: {item.mikor.Year}.{item.mikor.Month}.{item.mikor.Day}-{item.mikor.Hour-2}:{item.mikor.Minute}");
                    break;
                }
            }
        }
        static void f6()
        {

        }
        static void Main(string[] args)
        {
            beolvsa();
            //kiir();
            f2();
            f3();
            f4();
            f5();
            f6();


            Console.ReadKey();
        }
    }
}
