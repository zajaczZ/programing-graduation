﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pilotak
{
    class F1
    {
        public string nev;
        public DateTime szuletes;
        public string nemzetiseg;
        public int rajtszam;

    public F1(string sor)
        {
            string[] temp = sor.Split(';');
            nev = temp[0];
            szuletes = Convert.ToDateTime(temp[1]);
            nemzetiseg= temp[2];
            if (string.IsNullOrWhiteSpace(temp[3]))
            {
                rajtszam = 0;
            }
            else
            {
                rajtszam = int.Parse(temp[3]);
            }

        } 
    }
    internal class Program
    {
        static List<F1> lista= new List<F1>();
        static void beolvas()
        {
            StreamReader sr = new StreamReader("pilotak.csv");
            sr.ReadLine();
            while (!sr.EndOfStream)
            {
                F1 uj = new F1(sr.ReadLine());
                lista.Add(uj);
            }
            sr.Close();
        }
        static void kiir()
        {
            foreach (var item in lista)
            {
                Console.WriteLine(item.rajtszam);

            }
        }
        static void f3()
        {
            Console.WriteLine($"3.feladat: {lista.Count()}");
        }
        static void f4()
        {
            Console.WriteLine($"4.feladat: {lista.Select(X=>X.nev).Last()}");
        }
        static void f5()
        {
            Console.WriteLine("5.feladat: ");
            foreach (var item in lista)
            {
                if (item.szuletes.Year<1901)
                {
                    Console.WriteLine($"{item.nev} ({item.szuletes.ToShortDateString()})");

                }

            }
        }
        static void f6()
        {
            int kicsi = lista.Where(x=>x.rajtszam!=0).Min(x=>x.rajtszam);
            foreach (var item in lista)
            {
                if (kicsi==item.rajtszam)
                {
                    Console.WriteLine($"6.feladat: {item.nemzetiseg}");

                }

            }

        }
        static void f7()
        {
            
        }
        static void Main(string[] args)
        {
            beolvas();
            //kiir();
            f3();
            f4();
            f5();
            f6();

            Console.ReadKey();
        }
    }
}
