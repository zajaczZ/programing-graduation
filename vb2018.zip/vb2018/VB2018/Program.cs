﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VB2018
{
    class Foci
    {
        public string varos;
        public string nev1;
        public string nev2;
        public int ferohely;

        public Foci(string sor)
        {
            string[] temp = sor.Split(';');
            varos= temp[0];
            nev1= temp[1];
            nev2= temp[2];
            ferohely = int.Parse(temp[3]);
        
        }
    }
    internal class Program
    {
        static List<Foci> lista = new List<Foci>();
        static void beolvas()
        {
            StreamReader sr = new StreamReader("vb2018.txt",encoding:Encoding.UTF7);
            sr.ReadLine();
            while (!sr.EndOfStream)
            {
                Foci uj = new Foci(sr.ReadLine());
                lista.Add(uj);

            }
            sr.Close();

        }
        static void kiir()
        {
            foreach (var item in lista)
            {
                Console.WriteLine(item.varos);

            }
        }
        static void f3()
        {
            Console.WriteLine($"3.feladat: Stadionok száma: {lista.Count()}");

        }
        static void f4()
        {
            Console.WriteLine("4.feladat: A legkevesebb férőhely:");
            int kicsi = lista.Min(x => x.ferohely);
            foreach (var item in lista)
            {
                if (item.ferohely==kicsi)
                {
                    Console.WriteLine($"város: {item.varos}");
                    Console.WriteLine($"Stadion: neve: {item.nev1}");
                    Console.WriteLine($"Férőhely: {item.ferohely}");

                }
            }
        }
        static void f5()
        {
            Console.WriteLine($"5.feladat: Átlagos férőhelyszám: {Math.Round(lista.Average(x=>x.ferohely),1)}");
        }
        static void f6()
        {
            int darab = 0;
            foreach (var item in lista)
            {
                if (item.nev2!= "n.a.")
                {
                    darab++;
                }
            }
            Console.WriteLine($"6.feladat: Két néven is ismert stadionok száma: {darab}");
        }
        static void f7()
        {
            int darab = 0;
            string varos = "";
            while (varos.Length<3)
            {

                Console.WriteLine("7.feladat: Kérem a város nevét: ");
                varos=Console.ReadLine();

            }
            foreach (var item in lista)
            {
                if (item.varos==varos)
                {
                    darab++;
                }

            }
            if (darab>0)
            {
                Console.WriteLine($"A megadott város egy VB helyszín");
            }
            else
            {
                Console.WriteLine("A megadott város nem egy VB helyszín");
            }
        }
        static void f9()
        {
            int mennyi = lista.GroupBy(x=>x.varos).Count();
            Console.WriteLine($"9.feladat: {mennyi} különböző városban voltak mérkőzések");
        }
       
       

        static void Main(string[] args)
        {
            beolvas();
            //kiir();
            f3();
            f4();
            f5();
            f6();
            f7();
            f9();

            Console.ReadKey();
        }
    }
}
